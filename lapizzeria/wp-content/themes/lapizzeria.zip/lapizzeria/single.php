<?php get_header(); ?>
    <h1>Hola single.php</h1>
<?php get_footer(); ?>